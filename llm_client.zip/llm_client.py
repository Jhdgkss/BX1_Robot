import requests
import config

class LLMClient:
    def __init__(self):
        self.enabled = config.LLM_ENABLED
        self.messages = [
            {"role": "system", "content": config.SYSTEM_PROMPT}
        ]

    def ask(self, user_text: str) -> str:
        if not self.enabled:
            return ""

        self.messages.append({"role": "user", "content": user_text})

        response = requests.post(
            config.OLLAMA_URL,
            json={
                "model": config.OLLAMA_MODEL,
                "messages": self.messages,
                "stream": False,
            },
            timeout=120,
        )
        response.raise_for_status()
        data = response.json()

        reply = data.get("message", {}).get("content", "").strip()

        if reply:
            self.messages.append(
                {"role": "assistant", "content": reply}
            )

        return reply
