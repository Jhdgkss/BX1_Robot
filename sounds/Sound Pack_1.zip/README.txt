BX1 / LEO Robot Chirp Pack
============================

Format:
- WAV
- 24,000 Hz
- mono
- 16-bit PCM

Files:
wake.wav               Wake word recognised
listening.wav          STT/listening started
stt_complete.wav       STT completed
thinking.wav           Request sent to LLM
still_thinking.wav     Delayed cue while waiting
response_received.wav  LLM response available
error.wav              Error/failure cue

These are original synthetic robot/UI chirps designed for BX1/LEO.
They are not copies of any film or game sound effects.
